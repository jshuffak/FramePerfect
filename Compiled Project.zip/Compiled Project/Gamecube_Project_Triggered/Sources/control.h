#ifndef CONTROL_INCLUDED
#define CONTROL_INCLUDED

#include "input.h"
#include "macro.h"
#include "scheme.h"

Input GetNextInput(Input input);

#endif /* CONTROL_INCLUDED */